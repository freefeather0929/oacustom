package weaver.dh.interfaces;

public abstract interface toMiddleTable
{
  public abstract void execute(String paramString1, String paramString2, String paramString3);
}


/* Location:           F:\oa_back\oacustom\custom_class\dh\interfaces\
 * Qualified Name:     weaver.dh.interfaces.toMiddleTable
 * JD-Core Version:    0.7.0.1
 */